# AIC2026 L21 Evaluation Bootstrap

Automated extraction of the 150-case DOCX into query-side and hidden-GT JSONL.

Important: source frame references are preserved only as provisional raw references. Before strict evaluation, resolve BTC mapping CSV and use authoritative `frame_idx` for submission coordinates. Preserve duplicates. TRAKE `±4f` point windows are replaced in the draft by their exactly matching KIS/QA reference windows.

This is an integration regression benchmark, not the final blind benchmark.
